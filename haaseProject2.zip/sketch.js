var boardRadius = 12;
var choiceRadius = 4;
var size;
var choiceSize;
var originHex;
var choiceOriginHex;
var hexes = [];
var choiceHexes = [];
var mainLayout;
var choiceLayout;
var centerPoints = [];
var columns;
var minLength;
var maxLength;
var columnLength;
var mode;
var firstHexInColumn;
var stoneCenter;
var lavaCenter;
var grassCenter;
var waterCenter;
var forestCenter;
var selectedTile;
var tileTypes = [];
var choiceInnerRadius = 21.65;
var mainInnerRadius = 17.32; 
var stoneImg;
var lavaImg;
var grassImg;
var waterImg;
var forestImg;

//Preload Textures
function preload(){
  stoneImg = loadImage('assets/stone.png');
  lavaImg = loadImage('assets/lava.png');
  grassImg = loadImage('assets/grass.png');
  waterImg = loadImage('assets/water.png');
  forestImg = loadImage('assets/forest.png');
  stoneImgLarge = loadImage('assets/stoneLarge.png');
  lavaImgLarge = loadImage('assets/lavaLarge.png');
  grassImgLarge = loadImage('assets/grassLarge.png');
  waterImgLarge = loadImage('assets/waterLarge.png');
  forestImgLarge = loadImage('assets/forestLarge.png');
}

//Center point object constructor for storing x and y values
function centerPoint(x, y) {
  this.x = x;
  this.y = y;
}

//Tile object constructor
function Tile(Hex, tileType){
  this.Hex = Hex;
  this.tileType = tileType;
}

//Stores hex and tile type as a Tile object in an array to be drawn later
function mouseClicked(){
  if(dist(mouseX, mouseY, stoneCenter.x, stoneCenter.y) <= choiceInnerRadius){
    selectedTile = 'stone';
  }
  else if(dist(mouseX, mouseY, lavaCenter.x, lavaCenter.y) <= choiceInnerRadius){
    selectedTile = 'lava';
  }
  else if(dist(mouseX, mouseY, grassCenter.x, grassCenter.y) <= choiceInnerRadius){
  selectedTile = 'grass';
  }
  else if(dist(mouseX, mouseY, waterCenter.x, waterCenter.y) <= choiceInnerRadius){
  selectedTile = 'water';
  }
  else if(dist(mouseX, mouseY, forestCenter.x, forestCenter.y) <= choiceInnerRadius){
    selectedTile = 'forest';
  }
  for(let i=0; i<centerPoints.length; i++){
    if(dist(mouseX, mouseY, centerPoints[i].x, centerPoints[i].y) <= mainInnerRadius){
      tileTypes[i] = new Tile(hexes[i], selectedTile);
    }
  }
}

function setup()
{
  createCanvas(1000, 1000);
  background(225);
//Generates main grid
  angleMode(DEGREES);
  size = Point(20, 20);
  originPixel = Point(width/2, height/2);
  mainLayout = hexLayout(pointyOrient, size, originPixel);
  hexGenerateBoard(boardRadius, hexes, Hex(0,0,0));
  originHex = Hex(0,0,0);
//Generates grid for tile selection 
  choiceSize = Point(25, 25);
  choiceOriginPixel = Point(width/2, height/2);
  choiceLayout = hexLayout(pointyOrient, choiceSize, choiceOriginPixel);
  hexGenerateBoard(choiceRadius, choiceHexes, Hex(0,0,0));
  choiceOriginHex = Hex(0,0,0);
//Initialize center points for selection tiles
  stoneCenter = new centerPoint(326.8, 70);
  lavaCenter = new centerPoint(413.4, 70);
  grassCenter = new centerPoint(500, 70);
  waterCenter = new centerPoint(586.6, 70);
  forestCenter = new centerPoint(673.2, 70);
//Create array of center points for hexes
  columns = 13;
  minLength = 13;
  maxLength = 25;
  columnLength = minLength;
  mode = true;
  let count = 0;
  for(let i=0; i<hexes.length; i++){
  //Initialize first hex center point
    if(i==0){
      centerPoints[i] = new centerPoint(84.32, 550);
      firstHexInColumn = centerPoints[i];
    }
    if(count == 0){
      centerPoints[i] = firstHexInColumn;
    }
  //Adds center points down the column
    else if(count > 0 && count < columnLength && mode == true){
      centerPoints[i] = new centerPoint(centerPoints[i-1].x + mainInnerRadius, centerPoints[i-1].y + 30);
    }  
        else if(count > 0 && count < columnLength && mode == false){
      centerPoints[i] = new centerPoint(centerPoints[i-1].x + mainInnerRadius, centerPoints[i-1].y + 30);
    }  
    //Switches from increasing column size to decreasing column size after largest column
    if(columnLength == maxLength){
      mode = false;
    }
    count++;
    //Increases column size and sets new starting hex
    if(mode == true && count == columnLength && columnLength != maxLength){
      columnLength++;
      firstHexInColumn = new centerPoint(firstHexInColumn.x + mainInnerRadius, firstHexInColumn.y - 30);
      count = 0;
    }
    else if(mode == true && count == columnLength && columnLength == maxLength){
      columnLength++;
      firstHexInColumn = new centerPoint(firstHexInColumn.x + (mainInnerRadius*2), firstHexInColumn.y);
      count = 0;
    }
    else if(mode == false && count == columnLength){
      if(columnLength > minLength){
        columnLength--;
        firstHexInColumn = new centerPoint(firstHexInColumn.x + (mainInnerRadius*2), firstHexInColumn.y);
        count = 0;
      }
    }

  }
  //console.log(centerPoints); -for debugging
}

function draw()
{
  stroke(0);
  background(225);
  //text("X: "+mouseX, 0, height/4); -for debugging
  //text("Y: "+mouseY, 0, height/2); -for debugging
//Draw main grid
  translate(width/2, 550);
  fill('white');
  hexDrawArray(mainLayout, hexes);
//Draw hexes for tile selection grid
  noFill();
  translate(-width/2, -550);
  image(grassImgLarge, grassCenter.x-choiceInnerRadius, grassCenter.y - 25);
  translate(width/2, 70);
  //hexDraw(choiceLayout, Hex(0, 0, 0)); -uncommenting this will add a border around tile selection hexes
  translate(-width/2, -70);
  image(stoneImgLarge, stoneCenter.x-choiceInnerRadius, stoneCenter.y - 25);
  translate(width/2, 70);
 // hexDraw(choiceLayout, Hex(-4, 4, 0)); -uncommenting this will add a border around tile selection hexes
  translate(-width/2, -70);
  image(lavaImgLarge, lavaCenter.x-choiceInnerRadius, lavaCenter.y - 25);
  translate(width/2, 70);
 // hexDraw(choiceLayout, Hex(-2, 2, 0)); -uncommenting this will add a border around tile selection hexes
  translate(-width/2, -70);
  image(forestImgLarge, forestCenter.x-choiceInnerRadius, forestCenter.y - 25);
  translate(width/2, 70);
 // hexDraw(choiceLayout, Hex(4, -4, 0)); -uncommenting this will add a border around tile selection hexes
  translate(-width/2, -70);
  image(waterImgLarge, waterCenter.x-choiceInnerRadius, waterCenter.y - 25);
  translate(width/2, 70);
 // hexDraw(choiceLayout, Hex(2, -2, 0)); -uncommenting this will add a border around tile selection hexes
//Reset origin point
  translate(-width/2, -70);
//Draw tiles from array
  noFill();
  for(let i=0; i<tileTypes.length; i++){
    if(tileTypes[i] != null){
      if(tileTypes[i].tileType == 'stone'){
        image(stoneImg, centerPoints[i].x-mainInnerRadius, centerPoints[i].y-20);
        translate(width/2, 550);
        hexDraw(mainLayout, hexes[i]);
        translate(-width/2, -550);
      }
      else if(tileTypes[i].tileType == 'lava'){
        image(lavaImg, centerPoints[i].x-mainInnerRadius, centerPoints[i].y-20);
        translate(width/2, 550);
        hexDraw(mainLayout, hexes[i]);
        translate(-width/2, -550);
      }
      if(tileTypes[i].tileType == 'grass'){
        image(grassImg, centerPoints[i].x-mainInnerRadius, centerPoints[i].y-20);
        translate(width/2, 550);
        hexDraw(mainLayout, hexes[i]);
        translate(-width/2, -550);
      }
      if(tileTypes[i].tileType == 'water'){
        image(waterImg, centerPoints[i].x-mainInnerRadius, centerPoints[i].y-20);
        translate(width/2, 550);
        hexDraw(mainLayout, hexes[i]);
        translate(-width/2, -550);
      }
      if(tileTypes[i].tileType == 'forest'){
        image(forestImg, centerPoints[i].x-mainInnerRadius, centerPoints[i].y-20);
        translate(width/2, 550);
        hexDraw(mainLayout, hexes[i]);
        translate(-width/2, -550);
      }
    }
  }
}